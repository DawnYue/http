MySchedule

<img width="809" alt="image" src="https://user-images.githubusercontent.com/75625953/147281155-032f0f55-7c69-4ed6-a408-8c6c922500a2.png">


MyWidgets

<img width="280" alt="image" src="https://user-images.githubusercontent.com/75625953/147281084-fc216e07-f2c4-4d45-a2e6-188e04a26c68.png">
