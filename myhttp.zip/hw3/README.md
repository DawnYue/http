## CSCI 4131 – Fall 2021 Internet Programming Assignment 3
Sep 29, 2021
Utilized the **Google Map API**.

### Form
Autocomplete:


<img width="709" alt="image" src="https://user-images.githubusercontent.com/75625953/147283098-eafd4d35-93db-4b9f-8608-def19b65cf41.png">



Choose a place in the map:


<img width="692" alt="image" src="https://user-images.githubusercontent.com/75625953/147283876-6b05c566-a2f4-4565-b9c7-477529a640fe.png">


The form after submission:

<img width="493" alt="image" src="https://user-images.githubusercontent.com/75625953/147283216-d3b0c10d-c18b-4ef1-94fc-589d8ef23045.png">


### Schedule

![image](https://user-images.githubusercontent.com/75625953/147283984-b86058f2-08cb-4914-932d-a8c8e26a156b.png)


![image](https://user-images.githubusercontent.com/75625953/147284048-96a53d3a-1ca4-4b12-85b7-3c6e8acf2438.png)


![image](https://user-images.githubusercontent.com/75625953/147284142-5223b1e9-2f3a-4069-89c8-1b8bfdc502e2.png)
