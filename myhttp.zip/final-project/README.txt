User name: *****
Password: ********

Connection string: 
mongodb+srv://*****:********@cluster0.kfdxu.mongodb.net/schedule?retryWrites=true&w=majority

